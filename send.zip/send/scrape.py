from selenium import webdriver
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException
from selenium.webdriver.common.by import By
import time
import csv
import os
from datetime import datetime

csv_header = [['DATE', 'TIME', 'PRIMARY_TICKER', 'CALCULATE_TICKER']]


def wait_until_load(by, value):
    try:
        WebDriverWait(driver, 10).until(EC.presence_of_element_located((by, value)))
        print('page loaded')
        return True
    except TimeoutException:
        print("Loading took too much time!")
        return False


def write_direct_csv(lines, filename):
    with open('output/%s' % filename, 'a', encoding="utf-8", newline='') as csv_file:
        writer = csv.writer(csv_file, delimiter=',')
        writer.writerows(lines)
    csv_file.close()


def write_csv(lines, filename):
    if not os.path.isdir('output'):
        os.mkdir('output')
    if not os.path.isfile('output/%s' % filename):
        write_direct_csv(lines=csv_header, filename=filename)
    write_direct_csv(lines=lines, filename=filename)


driver = webdriver.Chrome(executable_path='chromedriver.exe')
driver.get("https://www.tradingview.com/chart/PiPMAZfh/")

wait_until_load(By.CLASS_NAME, 'tv-header__device-signin')
driver.find_element_by_xpath('/html/body/div[2]/div[3]/div[1]/div[2]/div[3]/a').click()

wait_until_load(By.CSS_SELECTOR, 'input[name="username"]')
username = driver.find_element_by_tag_name("input[name='username']")
username.clear()
username.send_keys("sanforce")

wait_until_load(By.CSS_SELECTOR, 'input[name="password"]')
password = driver.find_element_by_tag_name("input[name='password']")
password.clear()
password.send_keys("PythonProject1")

submit = driver.find_element_by_tag_name('button[type="submit"]')
submit.click()

driver.maximize_window()
wait = wait_until_load(By.XPATH,
                '/html/body/div[2]/div[1]/div[3]/div[1]/div/table/tr[1]/td[2]/div/div[2]/div/div[2]/div/div[5]/div[2]')
if not wait:
    driver.close()

time.sleep(6)
primary_ticker = driver.find_element_by_xpath(
    '/html/body/div[2]/div[1]/div[3]/div[1]/div/table/tr[1]/td[2]/div/div[2]/div/div[2]/div/div[5]/div[2]').text
calculate_ticker = driver.find_element_by_xpath(
    '/html/body/div[2]/div[1]/div[3]/div[1]/div/table/tr[3]/td[2]/div/div[2]/div/div[2]/div[2]/div[3]/div/div/div').text

driver.close()

if not primary_ticker:
    print('Not calculated primary ticker')
if not calculate_ticker:
    print('Not calculated calculated ticker')

date = datetime.today().strftime('%Y-%m-%d')
time = datetime.now().time()
line = [date, time, primary_ticker, calculate_ticker]
print(line)

write_csv(lines=[line], filename='TradingView.csv')
